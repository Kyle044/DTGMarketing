<!DOCTYPE html>
<html>

<?php include('headerdito.php') ?>
<body>








<section class="carsec1">
<img src="../img/agentEdit.jpg" alt="">
<div class="caright">
<h1>Come Join The Fun!</h1>
<p>Datagen is the flexible platform for employees to join it combines thoughtful design with serious smarts. Our employee is build from the ground-up to have a standardize work and skills </p>
</div>
</section>

<div class="carTitle">
    <h1>Career's We Offer!</h1>
</div>

<section class="carsec2">
<div class="leleft">
<div class="carhead" style="background:#EC994B;">
    <h1>Ca-Ching. Get Paid Fast.</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio neque a provident
         perspiciatis? Illo fugiat obcaecati minus quae culpa earum.</p>
</div>
<div class="carimg">
    <img src="../img/cardImg.jpg" alt="">
</div>
<div class="carimg">
    <img src="../img/cardImg.jpg" alt="">
</div>
<div class="carhead" style="background:#73777B;">
    <h1>Ca-Ching. Get Paid Fast.</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio neque a provident
         perspiciatis? Illo fugiat obcaecati minus quae culpa earum.</p>
</div>
</div>
<div class="riright">
    <div class="carimg">
    <img src="../img/cardImg.jpg" alt="">
</div>
<div class="carhead" style="background:#15133C;" >
    <h1>Ca-Ching. Get Paid Fast.</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio neque a provident
         perspiciatis? Illo fugiat obcaecati minus quae culpa earum.</p>
</div>
<div class="carhead">
    <h1>Ca-Ching. Get Paid Fast.</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Optio neque a provident
         perspiciatis? Illo fugiat obcaecati minus quae culpa earum.</p>
</div>
    <div class="carimg">
    <img src="../img/cardImg.jpg" alt="">
</div>
</div>





</section>


<?php include('footerdito.php') ?>
</body>
</html>
