<!DOCTYPE html>
<html>

<?php include('headerdito.php') ?>
<body>
   

<div class="ar1Container">


<h1>Datagen signed a MOA with Protec International Institute (TESDA-Accredited Institute)</h1>


<div class="ar1ComboPic">
    <img src="../img/gallery/8.JPG" alt="">
    <p>Datagen Facilities, OPC a Business Process Outsourcing (BPO) company inked a Memorandum of Agreement with
         Protec International Institute (TESDA-Accredited Institute) on July 4, 2022. The agreement is to provide
          opportunities for career growth and professional development of the future leaders in BPO industry.
           It is part of the implementation of Supervised Industry Learning (SIL) for Contact Center Services NCII.
        Part of our advocacy in Datagen, is to promote collaborative learning by engaging the students to learn, to grow, 
        to develop their skills, and eventually offer job opportunities. 

</p>
</div>




<div class="ar1Combo">
<h1>The old way of experiencing the internet requires you to give away your personal data.</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate consectetur aliquid fugiat iste, 
    quaerat sunt provident quibusdam vero esse rem! 
Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate consectetur aliquid fugiat iste, 
    quaerat sunt provident quibusdam vero esse rem!
Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate consectetur aliquid fugiat iste, 
    quaerat sunt provident quibusdam vero esse rem!
Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate consectetur aliquid fugiat iste, 
    quaerat sunt provident quibusdam vero esse rem!
Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate consectetur aliquid fugiat iste, 
    quaerat sunt provident quibusdam vero esse rem!
Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate consectetur aliquid fugiat iste, 
    quaerat sunt provident quibusdam vero esse rem!
Lorem ipsum dolor sit amet consectetur adipisicing elit. Cupiditate consectetur aliquid fugiat iste, 
    quaerat sunt provident quibusdam vero esse rem!</p>
   
    
</div>





</div>

<div class="ar2Container">

    <h1>Your Company deserves that edge</h1>

<div class="ar2ComboPic">
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Culpa a ipsa dolorem est perspiciatis nemo 
        ipsam modi, eum alias necessitatibus quo commodi placeat officia libero aliquam 
        explicabo itaque minus reiciendis. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Culpa a ipsa dolorem est perspiciatis nemo 
        ipsam modi, eum alias necessitatibus quo commodi placeat officia libero aliquam 
        explicabo itaque minus reiciendis.
    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Culpa a ipsa dolorem est perspiciatis nemo 
        ipsam modi, eum alias necessitatibus quo commodi placeat officia libero aliquam 
        explicabo itaque minus reiciendis.
    Lorem ipsum dolor sit, amet consectetur adipisicing elit. Culpa a ipsa dolorem est perspiciatis nemo 
        ipsam modi, eum alias necessitatibus quo commodi placeat officia libero aliquam 
        explicabo itaque minus reiciendis.
 
   </p>
        
    <img src="../img/gallery/hehehe.JPG" alt="">
</div>
</div>






<?php include('footerdito.php') ?>
</body>
</html>
