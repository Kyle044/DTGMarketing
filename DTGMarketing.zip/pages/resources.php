<!DOCTYPE html>
<html>
<?php include('headerdito.php') ?>
<body>
    <div class="reCol1"><ul><li>Latest</li>
<li>Management</li>
<li>Marketing</li></ul></div>
<div class="resourcesMainContainer">

<div class="reCol2">
    <div class="cardReso">
    <img src="../img/cardImg.jpg" alt="">
    <div class="titleDiv">
       <h3> Lorem ipsum dolor sit amet.</h3>
    </div>
    <div class="desDiv">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At a veniam nulla nostrum cumque, esse hic quia aliquid velit facilis?</p>
    </div>
    <div class="autDiv">
        <p>Bogart</p>
    </div>
</div>
<div class="cardReso">
    <img src="../img/cardImg.jpg" alt="">
    <div class="titleDiv">
       <h3> Lorem ipsum dolor sit amet.</h3>
    </div>
    <div class="desDiv">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At a veniam nulla nostrum cumque, esse hic quia aliquid velit facilis?</p>
    </div>
    <div class="autDiv">
        <p>Bogart</p>
    </div>
</div>
<div class="cardReso">
    <img src="../img/cardImg.jpg" alt="">
    <div class="titleDiv">
       <h3> Lorem ipsum dolor sit amet.</h3>
    </div>
    <div class="desDiv">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At a veniam nulla nostrum cumque, esse hic quia aliquid velit facilis?</p>
    </div>
    <div class="autDiv">
        <p>Bogart</p>
    </div>
</div>
<div class="cardReso">
    <img src="../img/cardImg.jpg" alt="">
    <div class="titleDiv">
       <h3> Lorem ipsum dolor sit amet.</h3>
    </div>
    <div class="desDiv">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At a veniam nulla nostrum cumque, esse hic quia aliquid velit facilis?</p>
    </div>
    <div class="autDiv">
        <p>Bogart</p>
    </div>
</div>
</div>
<div class="reCol3">

 <div class="cardReso">
    <img src="../img/cardImg.jpg" alt="">
    <div class="titleDiv">
       <h3> Lorem ipsum dolor sit amet.</h3>
    </div>
    <div class="desDiv">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At a veniam nulla nostrum cumque, esse hic quia aliquid velit facilis?</p>
    </div>
    <div class="autDiv">
        <p>Bogart</p>
    </div>
</div>
 <div class="cardReso">
    <img src="../img/cardImg.jpg" alt="">
    <div class="titleDiv">
       <h3> Lorem ipsum dolor sit amet.</h3>
    </div>
    <div class="desDiv">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At a veniam nulla nostrum cumque, esse hic quia aliquid velit facilis?</p>
    </div>
    <div class="autDiv">
        <p>Bogart</p>
    </div>
</div>
 <div class="cardReso">
    <img src="../img/cardImg.jpg" alt="">
    <div class="titleDiv">
       <h3> Lorem ipsum dolor sit amet.</h3>
    </div>
    <div class="desDiv">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At a veniam nulla nostrum cumque, esse hic quia aliquid velit facilis?</p>
    </div>
    <div class="autDiv">
        <p>Bogart</p>
    </div>
</div>


</div>
<div class="reCol4">


 <div class="cardReso">
    <img src="../img/cardImg.jpg" alt="">
    <div class="titleDiv">
       <h3> Lorem ipsum dolor sit amet.</h3>
    </div>
    <div class="desDiv">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At a veniam nulla nostrum cumque, esse hic quia aliquid velit facilis?</p>
    </div>
    <div class="autDiv">
        <p>Bogart</p>
    </div>
</div>
 <div class="cardReso">
    <img src="../img/cardImg.jpg" alt="">
    <div class="titleDiv">
       <h3> Lorem ipsum dolor sit amet.</h3>
    </div>
    <div class="desDiv">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At a veniam nulla nostrum cumque, esse hic quia aliquid velit facilis?</p>
    </div>
    <div class="autDiv">
        <p>Bogart</p>
    </div>
</div>
 <div class="cardReso">
    <img src="../img/cardImg.jpg" alt="">
    <div class="titleDiv">
       <h3> Lorem ipsum dolor sit amet.</h3>
    </div>
    <div class="desDiv">
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. At a veniam nulla nostrum cumque, esse hic quia aliquid velit facilis?</p>
    </div>
    <div class="autDiv">
        <p>Bogart</p>
    </div>
</div>


</div>
</div>
<?php include('footerdito.php') ?>
</body>
</html>
