<!DOCTYPE html>
<html>
<?php include('headerdito.php') ?>

<body>
    <div class="gMasterContainer">
<div class="galleryContainer" style="transform:translateY(2rem)">
    <div class="galleryheading" style="margin-top:1rem;">
    <h3 class="text-bold" style="color:white;" >2022</h3>
    <p style="color:white;" >We are delighted to announce our partnership with Protec International Institute (TESDA-Accredited Institute) and Datagen Facilities OPC, signed last July 4, 2022. 
    The partnership reflects an open exchange of information and personnel between the two companies that aims to provide more opportunities for career growth and professional development. </p>
    </div>

    <div class="buttonGroup">
    <button class="btnKo" style="background:white; color:black;" >All</button>
    <button class="btnKo" style="background:white; color:black;">Office</button>
    </div>
   <div class="gallery">
    <a href="../img/gallery/1.JPEG" data-lightbox="mygallery"><img src="../img/gallery/1.JPEG" alt=""></a>
    <a href="../img/gallery/2.JPEG" data-lightbox="mygallery"><img src="../img/gallery/2.JPEG" alt=""></a>
    <a href="../img/gallery/3.JPEG" data-lightbox="mygallery"><img src="../img/gallery/3.JPEG" alt=""></a>
    <a href="../img/gallery/3.JPEG" data-lightbox="mygallery"><img src="../img/gallery/3.JPEG" alt=""></a>
    <a href="../img/gallery/2.JPEG" data-lightbox="mygallery"><img src="../img/gallery/2.JPEG" alt=""></a>
    <a href="../img/gallery/1.JPEG" data-lightbox="mygallery"><img src="../img/gallery/1.JPEG" alt=""></a>
    </div>
</div>

 </div>
<div class="galleryContainer" style="margin-top:2rem;">
    <div class="galleryheading">
    <h3>2021</h3>
    <p>Christmas party held in datagen cavite</p>
    </div>

   <div class="gallery">
    <a href="../img/gallery/4.JPG" data-lightbox="mygallery"><img src="../img/gallery/4.JPG" alt=""></a>
    <a href="../img/gallery/5.JPG" data-lightbox="mygallery"><img src="../img/gallery/5.JPG" alt=""></a>
    <a href="../img/gallery/6.JPG" data-lightbox="mygallery"><img src="../img/gallery/6.JPG" alt=""></a>
    <a href="../img/gallery/7.JPG" data-lightbox="mygallery"><img src="../img/gallery/7.JPG" alt=""></a>
    <a href="../img/gallery/8.JPG" data-lightbox="mygallery"><img src="../img/gallery/8.JPG" alt=""></a>
    <a href="../img/gallery/9.JPG" data-lightbox="mygallery"><img src="../img/gallery/9.JPG" alt=""></a>
    <a href="../img/gallery/10.JPG" data-lightbox="mygallery"><img src="../img/gallery/10.JPG" alt=""></a>
    <a href="../img/gallery/11.JPG" data-lightbox="mygallery"><img src="../img/gallery/11.JPG" alt=""></a>
    </div>
</div>
   

 
    <?php include('footerdito.php') ?>

</body>

</html>